//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
//

#include "UnderlayConfigurator.h"

Define_Module(UnderlayConfigurator);

UnderlayConfigurator::UnderlayConfigurator() {
    lcCreated = 0;
}

UnderlayConfigurator::~UnderlayConfigurator() {

}

int UnderlayConfigurator::numInitStages() const {
    return 1;
}

void UnderlayConfigurator::initialize(int stage) {
    nextFreeAddress = 0x1000001;
    globalNodeList = GlobalNodeListAccess().get();
}

void UnderlayConfigurator::handleMessage(cMessage* msg) {

}

TransportAddress* UnderlayConfigurator::createLogicComputer() {
    const char* hostType = "ned.LogicComputer";
    const char* hostName = "logicComputer";

    // create a new node
    cModuleType *moduleType = cModuleType::get(hostType);
    cModule* parent = getParentModule();
    // create (possibly compound) module and build its submodules (if any)
    cModule *LC = moduleType->create(hostName, parent, lcCreated + 1,
            lcCreated);

    // set up parameters, if any
    LC->finalizeParameters();

    LC->buildInside();

    // create activation message
    LC->scheduleStart(simTime());
    LC->callInitialize();

    // create address for the Rendezvous node
    IPvXAddress addr = IPAddress(nextFreeAddress++);
    GatebasedModule* rendezvous = check_and_cast<GatebasedModule*>(
            LC->getSubmodule("rendezvous"));
    rendezvous->setAddress(addr);
    // create meta information
    SimpleNodeEntry* entry = new SimpleNodeEntry(rendezvous);
    SimpleInfo* info = new SimpleInfo(rendezvous->getId());
    info->setEntry(entry);
    //add node to bootstrap oracle
    globalNodeList->addPeer(addr, info);

    TransportAddress *address = new TransportAddress(addr);

    return address;
}

TransportAddress* UnderlayConfigurator::registerEndpoint(cModule* host) {
    IPvXAddress addr = IPAddress(nextFreeAddress++);
    // create meta information
    SimpleNodeEntry* entry = new SimpleNodeEntry(host);
    SimpleInfo* info = new SimpleInfo(host->getId());
    info->setEntry(entry);
    //add node to bootstrap oracle
    globalNodeList->addPeer(addr, info);

    TransportAddress *address = new TransportAddress(addr);

    return address;
}

TransportAddress* UnderlayConfigurator::createNode(cModule* parent,
        int nodeCreated) {
    const char* hostType = "ned.Node";
    const char* hostName = "node";

    // create a new node
    cModuleType *moduleType = cModuleType::get(hostType);
    // create (possibly compound) module and build its submodules (if any)
    cModule *host = moduleType->create(hostName, parent, nodeCreated + 1,
            nodeCreated);
    string nodeName = host->getFullName();
    EV << "[" << simTime() << "s] create host: " << nodeName << endl;

    // set up parameters, if any
    host->finalizeParameters();

    host->buildInside();

    // create activation message
    host->scheduleStart(simTime());
    host->callInitialize();

    IPvXAddress addr = IPAddress(nextFreeAddress++);
    IPv4InterfaceData* ipData = new IPv4InterfaceData();
    ipData->setIPAddress(addr.get4());
    InterfaceEntry* ie = new InterfaceEntry();
    ie->setName("IPAddress");
    ie->setIPv4Data(ipData);
    InterfaceTable* interface = InterfaceTableAccess().get(host);
    interface->addInterface(ie);
    // create meta information
    SimpleNodeEntry* entry = new SimpleNodeEntry(host);
    SimpleInfo* info = new SimpleInfo(host->getId());
    info->setEntry(entry);
    //add node to bootstrap oracle
    globalNodeList->addPeer(addr, info);

    TransportAddress *address = new TransportAddress(addr);

    return address;
}
